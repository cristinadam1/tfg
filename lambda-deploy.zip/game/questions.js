module.exports = {
    IMAGEN: [
      {
        question: "¿Qué ciudad es conocida como 'La ciudad del amor'?",
        answers: ["París", "Paris", "ciudad de París", "ciudad de Paris"],
        hints: ["Está en Francia", "Tiene una famosa torre"],
        difficulty: 1
      },
      {
        question: "¿Cuál es el plato típico de Italia que se hace con masa y tomate?",
        answer: "pizza",
        hints: ["Se hornea", "Tiene queso"],
        difficulty: 1
      }
    ],
    NIÑOS: [
      {
        question: "¿Cómo se llama el programa infantil de los años 80 y 90 donde aparecían Espinete y Don Pimpón?",
        answer: "el barco de vapor",
        hints: ["Era un programa de TVE", "Tenía un estudio con niños"],
        difficulty: 2
      }
    ]
  };